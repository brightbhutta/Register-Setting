<?php
/**
 * Plugin Name:       Register Settings Plugin
 * Plugin URI:        https://example.com/plugins/register-settings
 * Description:       Register Settings options with this plugin.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Tanveer Bhutta
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/register-settings
 * Text Domain:       register-settings
 * Domain Path:       /languages
 */

 function show_register_menu(){

    add_menu_page( 'Register Setting', 'Register Setting', 'manage_options', 'register_setting', 'register_setting_function', 'dashicons-welcome-widgets-menus' );
 }
add_action('admin_menu', 'show_register_menu');

function initialize(){
    register_setting( 'general-group', 'header_title' ); 

    add_settings_section( 'header-setting', 'Header Options', 'header_option_callback', 'register_setting');

    add_settings_field( 'header-title-field', 'Header Title', 'header_title_func', 'register_setting',  'header-setting');

}
add_action('admin_init', 'initialize');

function header_option_callback(){
    echo "you can manage Header options";
}

function header_title_func(){
    $value = get_option('header_title');
 ?>

    <input type="text" name="header_title" value="<?php echo $value; ?>" >

<?php 
}

function register_setting_function(){

    echo "<h1>Tanveer Bhutta</h1>";
    ?>

    <form method="POST" accept="option.php">
        <?php echo settings_fields('general-group'); ?>
        <?php echo do_settings_sections('register_setting'); ?>
        <?php submit_button(); ?>

    </form>

<?php

}